package Tests;

import org.testng.annotations.Test;

import Pages.HomePage;

public class Registracija extends TestsParameters{

	// aktorius užeina į pagrindinį langą, paspaudžia mygtuką "sukurti naują paskyrą", suveda prisijungimo duomenis (sėkmės scenarijus)
	
	@Test
	public void Registracija() throws Exception {
		driver.navigate().to("http://localhost:8080/prisijungti");
		
		HomePage hp = new HomePage (driver);
		hp.SignUp();
		hp.SignUpData("gabdrr", "3737373", "3737373");
		hp.SubmittApplication();
		System.out.println("Sign up successful.");
		Thread.sleep(3000);
		
//		System.out.println("Mano testas");
	}
	
	@Test
	//  Aktorius įveda egzistuojančios paskyros duomenis (nesėkmės atvejis)
	public void Registracija2() throws Exception{
		driver.navigate().to("http://localhost:8080/prisijungti");
		
		HomePage hp = new HomePage (driver);
		hp.SignUp();
		hp.SignUpData("gabdri", "3737373", "3737373");
		hp.SubmittApplication();
		hp.CatchAlerts();
		Thread.sleep(3000);
	}
}
