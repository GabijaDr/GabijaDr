package Tests;

import org.testng.annotations.Test;

import Pages.HomePage;

public class Atsijungimas extends TestsParameters {
	
	// aktorius užeina į pagrindinį langą,  suveda prisijungimo duomenis, paspaudžia "logout admin" (sėkmės scenarijus)
	
			@Test
			public void Atsijungimas() throws Exception {
				driver.navigate().to("http://localhost:8080/skaiciuotuvas");
				
				HomePage hp = new HomePage (driver);
//				Thread.sleep(3000);
				hp.SignInData("gabdri", "3737373");
//				Thread.sleep(3000);
				hp.SubmitPrisijungti();
				hp.LogOut();
				hp.CatchAlertsLogOut();
				Thread.sleep(3000);
//				System.out.println("Mano testas");
			}

}