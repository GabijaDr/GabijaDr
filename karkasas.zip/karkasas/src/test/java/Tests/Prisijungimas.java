package Tests;

import org.testng.annotations.Test;

import Pages.HomePage;

public class Prisijungimas extends TestsParameters {

	// aktorius užeina į pagrindinį langą,  suveda prisijungimo duomenis (sėkmės scenarijus)
	
		@Test
		public void Prisijungimas() throws Exception {
			driver.navigate().to("http://localhost:8080/prisijungti");
			
			HomePage hp = new HomePage (driver);
//			Thread.sleep(3000);
			hp.SignInData("gabdri", "3737373");
//			Thread.sleep(3000);
			hp.SubmitPrisijungti();
			Thread.sleep(3000);
			System.out.println("Sign in successful.");
			Thread.sleep(3000);
			hp.LogOut();
//			System.out.println("Mano testas");
		}
		
		@Test
		//  Aktorius prisijungimo lange neįveda jokio vartotojo vardo  (nesėkmės atvejis)
		public void Prisijungimas2() throws Exception{
			driver.navigate().to("http://localhost:8080/prisijungti");
			
			HomePage hp = new HomePage (driver);
//			Thread.sleep(3000);
			hp.SignInData("", "3737373");
//			Thread.sleep(3000);
			hp.SubmitPrisijungti();
			hp.CatchAlertsLogin();
			
		} 
}
