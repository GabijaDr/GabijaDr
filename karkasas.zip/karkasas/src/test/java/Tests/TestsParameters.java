package Tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class TestsParameters {
protected static WebDriver driver;
	
	@BeforeTest
	public void SetUp() {
		driver = new ChromeDriver();
//		WebDriver driver = new FirefoxDriver();
		driver.manage().window().maximize();
				
	}
	
	@AfterTest
	public void TearDown() {
		driver.manage().deleteAllCookies();
		driver.close();
	}
	
}
