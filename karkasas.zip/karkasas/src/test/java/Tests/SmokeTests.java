package Tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;

public class SmokeTests {


	protected static WebDriver driver;

@BeforeTest
public void setUp() {
	driver = new ChromeDriver();
	driver.manage().window().maximize();

}
}package Tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;

public class SmokeTests {


	protected static WebDriver driver;

@BeforeTest
public void setUp() {
	driver = new ChromeDriver();
	driver.manage().window().maximize();

}
}